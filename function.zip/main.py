import os
from google.cloud import storage
from google.auth import default
from google.auth.transport import requests
from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

BUCKET_NAME = os.environ.get("BUCKET_NAME")

@app.route("/get-upload-url", methods=["POST"])
def get_upload_url(request):
    credentials, project = default()
    if credentials.token is None:
        credentials.refresh(requests.Request())
    client = storage.Client(credentials=credentials, project=project)
    # client = storage.Client()  # Uses default credentials from Cloud Function
    bucket = client.bucket(BUCKET_NAME)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    blob = bucket.blob(f"uploads/{timestamp}/")

    url = blob.generate_signed_url(
        version="v4",
        expiration=3600,  # URL valid for 1 hour
        method="PUT",
        content_type=request.json.get('contentType', 'application/octet-stream'),
        service_account_email="api-service-acct@snapshot-dev-363720.iam.gserviceaccount.com",
        access_token=credentials.token,
    )

    return jsonify({"url": url})